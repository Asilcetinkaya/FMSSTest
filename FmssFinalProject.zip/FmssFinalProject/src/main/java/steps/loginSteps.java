package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class loginSteps {
    private WebDriver driver;

    @Given("User is on the login page")
    public void navigateToLoginPage() {
        System.setProperty("webdriver.chrome.driver", "/Users/asil/Downloads/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }

    @When("User enters valid username {string}")
    public void user_enters_valid_username(String username) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);

    }

    @And("User enters valid password {string}")
    public void userClicksTheLoginButton(String password) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);

    }
    
    @And("User clicks the login button")
    public void userClicksTheLoginButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//button[@type='submit']")).click();

    }

    @Then("User should be redirected to the dashboard page")
    public void userShouldBeRedirectedToTheDashboardPage() {
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("/dashboard/index"));
        driver.quit();

    }



    @When("User enters invalid username {string}")
    public void userEntersInvalidUsername(String username) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);

        
    }

    @And("User enters invalid password {string}")
    public void userEntersInvalidPassword(String password) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);

    }

    @And("An error message should be displayed")
    public void anErrorMessageShouldBeDisplayed() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        Assert.assertTrue(driver.findElement(By.xpath("//div[@role='alert']")).isDisplayed());
        driver.quit();
    }

}
