package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;

import java.time.Duration;

import static org.junit.Assert.assertTrue;

public class searchSteps {

    private WebDriver driver;

    @Given("User is logged")
    public void navigateToLoginPage() {
        System.setProperty("webdriver.chrome.driver", "/Users/asil/Downloads/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Admin");
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("admin123");
        driver.findElement(By.xpath("//button[@type='submit']")).click();

    }

    @And("User is on the dashboard page")
    public void userIsOnTheDashboardPage() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");

    }

    @When("User enters {string} in the search box")
    public void userEntersInTheSearchBox(String StringSearchInput) {
        WebElement inputElement = driver.findElement(By.xpath("//input [@placeholder='Search']"));
        inputElement.sendKeys(StringSearchInput);

    }

    @And("User clicks the Admin button")
    public void userClicksTheSearchButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//button[@class='oxd-icon-button oxd-main-menu-button' and @type='button' and @role='none']/i[@class='oxd-icon bi-chevron-left']"));
        spanElement.click();

    }

    @Then("The results page should display relevant results for Admin")
    public void theResultsPageShouldDisplayRelevantResultsForAdmin() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement resultsDiv = driver.findElement(By.xpath("//span[.='Admin']"));
        boolean containsKeyword = resultsDiv.getText().contains("Admin");
        assertTrue(resultsDiv.getText().contains("Admin"));
        driver.quit();

    }

    @And("User clicks the PIM button")
    public void userClicksThePIMButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='PIM']"));
        spanElement.click();

    }

    @Then("The results page should display relevant results for PIM")
    public void theResultsPageShouldDisplayRelevantResultsForPIM() {
        WebElement resultsDiv = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module' and text()='PIM']"));
        boolean containsKeyword = resultsDiv.getText().contains("PIM");
        assertTrue("Results should contain the keyword: " + "PIM", containsKeyword);
        driver.quit();

    }

    @And("User clicks the Time button")
    public void userClicksTheTimeButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Time']"));
        spanElement.click();

    }

    @Then("The results page should display relevant results for Time")
    public void theResultsPageShouldDisplayRelevantResultsForTime() {
        WebElement resultsDiv = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module' and text()='Time']"));
        boolean containsKeyword = resultsDiv.getText().contains("Time");
        assertTrue("Results should contain the keyword: " + "Time", containsKeyword);
        driver.quit();

    }

    @And("User clicks the Leave button")
    public void userClicksTheLeaveButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Leave']"));
        spanElement.click();

    }

    @Then("The results page should display relevant results for Leave")
    public void theResultsPageShouldDisplayRelevantResultsForLeave() {
        WebElement resultsDiv = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module' and text()='Leave']"));
        boolean containsKeyword = resultsDiv.getText().contains("Leave");
        assertTrue("Results should contain the keyword: " + "Leave", containsKeyword);
        driver.quit();

    }

    @And("User clicks the Performance button")
    public void userClicksThePerformanceButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Performance']"));
        spanElement.click();

    }

    @Then("The results page should display relevant results for Performance")
    public void theResultsPageShouldDisplayRelevantResultsForPerformance() {
        WebElement resultsDiv = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module' and text()='Performance']"));
        boolean containsKeyword = resultsDiv.getText().contains("Performance");
        assertTrue("Results should contain the keyword: " + "Performance", containsKeyword);
        driver.quit();

    }

    @And("User clicks the Claim button")
    public void userClicksTheClaimButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Claim']"));
        spanElement.click();

    }

    @Then("The results page should display relevant results for Claim")
    public void theResultsPageShouldDisplayRelevantResultsForClaim() {
        WebElement resultsDiv = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module' and text()='Claim']"));
        boolean containsKeyword = resultsDiv.getText().contains("Claim");
        assertTrue("Results should contain the keyword: " + "Claim", containsKeyword);
        driver.quit();
    }

    @And("User clicks the Buzz button")
    public void userClicksTheBuzzButton() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement spanElement = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Buzz']"));
        spanElement.click();
    }

    @Then("The results page should display relevant results for Buzz")
    public void theResultsPageShouldDisplayRelevantResultsForBuzz() {
        WebElement resultsDiv = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module' and text()='Buzz']"));
        boolean containsKeyword = resultsDiv.getText().contains("Buzz");
        assertTrue("Results should contain the keyword: " + "Buzz", containsKeyword);
        driver.quit();

    }
}



